#!/bin/bash

# Set OpenStack environment variables
# export OS_AUTH_URL="https://your-openstack-auth-url"
# export OS_USERNAME="your-username"
# export OS_PASSWORD="your-password"
# export OS_PROJECT_NAME="your-tenant-name"
# export OS_REGION_NAME="RegionOne"

export OS_AUTH_TYPE=v3applicationcredential
export OS_AUTH_URL=https://identity.cloud.muni.cz/v3
export OS_IDENTITY_API_VERSION=3
export OS_REGION_NAME="brno1"
export OS_INTERFACE=public
export OS_APPLICATION_CREDENTIAL_ID=89b86f07b40842eca6802deec1828a53
export OS_APPLICATION_CREDENTIAL_SECRET=5qcx-IO5AlHV4E8rUw2EfUMnD_X3BZEtuHsLwQppqcPSngYiDP5v8hpPAJ7sh8ZTRIlGBhrOL8ufRpNtE3A9XA

export AWS_ACCESS_KEY_ID=bbe6c25a57bd4607b24022b94b521dc3
export AWS_SECRET_ACCESS_KEY=547d6ef7301544c2a81fadee22d79367

export TF_VAR_KYPO_ENDPOINT="https://images.crp.kypo.muni.cz"
export TF_VAR_CI_PROJECT_URL="https://github.com/xpanov/cshcz-test-sandbox"
export TF_VAR_CI_COMMIT_SHORT_SHA="2fd7acb"

export KYPO_USERNAME=user-2
export KYPO_PASSWORD=9frLVwLIya

# Initialize Terraform
echo "Initializing Terraform..."
tofu init

# Validate Terraform configuration
echo "Validating Terraform configuration..."
tofu validate

# Plan the deployment
echo "Planning Terraform deployment..."
tofu plan

# Apply the Terraform configuration
echo "Applying Terraform configuration..."
tofu apply -auto-approve

# Get and display the instance IP
echo "Fetching instance IP..."
tofu output instance_ip
